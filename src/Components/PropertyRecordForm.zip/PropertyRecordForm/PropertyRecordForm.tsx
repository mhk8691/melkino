import {useState} from 'react'
import {Box, Button, Stack, Tab, Tabs, Typography} from '@mui/material'
import type {Dispatch, SetStateAction} from 'react'

import {TypeGate} from './components/TypeGate'
import {BaseStep} from './steps/BaseStep'
import {FinancialStep} from './steps/FinancialStep'
import {TechnicalStep} from './steps/TechnicalStep'
import {OwnerStep} from './steps/OwnerStep'
import {ImagesStep} from './steps/ImagesStep'
import {DescriptionStep} from './steps/DescriptionStep'
import {MODE_TITLE, STEPS_BY_MODE, STEP_CONTENT_HEIGHT} from './constants'
import type {PropertyType, RecordMode} from './types'

export function PropertyRecordForm({
    property,
    setProperty,
    resource,
    mode = 'file',
}: {
    property: PropertyType
    setProperty: Dispatch<SetStateAction<PropertyType>>
    resource: string
    mode?: RecordMode
}) {
    const [activeTab, setActiveTab] = useState(0)

    const steps = STEPS_BY_MODE[mode]

    const handleChangeTab = (_event: React.SyntheticEvent, newValue: number) => {
        setActiveTab(newValue)
    }

    const handleNext = () => {
        setActiveTab((prev) => Math.min(prev + 1, steps.length - 1))
    }

    const handleBack = () => {
        setActiveTab((prev) => Math.max(prev - 1, 0))
    }

    const handleChangeType = () => {
        setProperty((prev) => ({...prev, contractType: ''}))
        setActiveTab(0)
    }

    if (!property) return null

    // پیش از شروع فرم (چه ثبت فایل، چه ثبت درخواست)، نوع باید مشخص شود
    if (!property.contractType) {
        return (
            <TypeGate
                value={property.contractType}
                title={mode === 'request' ? 'نوع درخواست را انتخاب کنید' : 'نوع فایل را انتخاب کنید'}
                onSelect={(value) =>
                    setProperty((prev) => ({
                        ...prev,
                        contractType: value,
                    }))
                }
            />
        )
    }

    const stepProps = {property, setProperty, resource}

    // نگاشت گام‌ها بر اساس حالت فرم
    const stepRenderers: Record<RecordMode, Array<() => React.ReactNode>> = {
        file: [
            () => <BaseStep {...stepProps} mode={mode} />,
            () => <FinancialStep {...stepProps} mode={mode} />,
            () => <TechnicalStep {...stepProps} mode={mode} />,
            () => <OwnerStep {...stepProps} />,
            () => <ImagesStep setProperty={setProperty} />,
            () => <DescriptionStep {...stepProps} />,
        ],
        request: [
            () => <BaseStep {...stepProps} mode={mode} />,
            () => <FinancialStep {...stepProps} mode={mode} />,
            () => <TechnicalStep {...stepProps} mode={mode} />,
            () => <DescriptionStep {...stepProps} />,
        ],
    }

    const renderStepContent = stepRenderers[mode][activeTab] ?? (() => null)

    return (
        <Stack spacing={3}>
            <Stack direction="row" justifyContent="space-between" alignItems="center">
                <Typography variant="subtitle2" color="text.secondary">
                    {MODE_TITLE[mode]} · {property.contractType}
                </Typography>

                <Button size="small" onClick={handleChangeType}>
                    تغییر نوع
                </Button>
            </Stack>

            <Tabs
                value={activeTab}
                onChange={handleChangeTab}
                variant="scrollable"
                scrollButtons="auto"
                allowScrollButtonsMobile
                sx={{
                    minHeight: 40,
                    borderBottom: 1,
                    borderColor: 'divider',
                    '& .MuiTab-root': {
                        minHeight: 40,
                        fontWeight: 600,
                    },
                }}
            >
                {steps.map((label) => (
                    <Tab key={label} label={label} />
                ))}
            </Tabs>

            <Box
                sx={{
                    minHeight: STEP_CONTENT_HEIGHT,
                    maxHeight: STEP_CONTENT_HEIGHT,
                    overflowY: 'auto',
                    pr: 0.5,
                    pt: 1.5,
                }}
            >
                {renderStepContent()}
            </Box>

            <Stack direction="row" justifyContent="space-between">
                <Button disabled={activeTab === 0} onClick={handleBack}>
                    مرحله قبل
                </Button>

                <Button
                    variant="contained"
                    disabled={activeTab === steps.length - 1}
                    onClick={handleNext}
                >
                    مرحله بعد
                </Button>
            </Stack>
        </Stack>
    )
}


