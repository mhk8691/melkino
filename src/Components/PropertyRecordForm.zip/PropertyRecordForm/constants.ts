import type {RecordMode} from './types'

export const STATUS_OPTIONS = ['فعال', 'فروخته شده', 'منصرف شد', 'کنسل شد']

export const PROPERTY_TYPE_OPTIONS = ['آپارتمان', 'ویلایی', 'زمین', 'پیش فروش']

// نوع قرارداد در گام اول (گیت) فقط بین این دو گزینه انتخاب می‌شود
export const GATE_CONTRACT_TYPE_OPTIONS = ['فروش', 'رهن و اجاره'] as const

export const DOCUMENT_TYPE_OPTIONS = [
    'تک برگ',
    'مبایعه نامه',
    'وکالت نامه',
    'سند مشاعی',
    'سند اوقافی',
    'سند مسکن ملی',
    'صلح نامه',
    'در دست اقدام',
]

export const CITY_OPTIONS = [
    'تهران',
    'مشهد',
    'اصفهان',
    'کرج',
    'شیراز',
    'تبریز',
    'اهواز',
    'قم',
    'کرمانشاه',
    'رشت',
    'ارومیه',
    'زاهدان',
    'کرمان',
    'اراک',
    'یزد',
]

export const OCCUPANCY_OPTIONS = ['تخلیه', 'مالک', 'مستاجر']

export const HEATING_OPTIONS = [
    'بومبلر',
    'داکت اسپلیت',
    'کولرآبی',
    'پکیج',
    'شوفاژ',
    'موج گرم',
    'ندارد',
]

export const COOLING_OPTIONS = ['کولر آبی', 'اسپلیت', 'داکت اسپلیت', 'پکیج', 'ارتفاع دار', 'ندارد']

export const FLOORING_OPTIONS = [
    'سرامیک',
    'پارکت',
    'موزاییک',
    'سنگ',
    'مربوط',
    'کاشی',
    'چوب',
    'لاموینت',
]

export const FACADE_OPTIONS = ['سنگ', 'آجر', 'رنگ', 'کامپوزیت', 'شیشه', 'فلز', 'ترکیبی']

export const DIRECTION_OPTIONS = [
    'شمال',
    'جنوب',
    'شرق',
    'غرب',
    'شمال شرق',
    'شمال غرب',
    'جنوب شرق',
    'جنوب غرب',
]

export const AMENITIES_OPTIONS = [
    'آسانسور',
    'پارکینگ',
    'انباری',
    'بالکن',
    'کابینت',
    'شیرآلات',
    'ورزشی',
    'لابی',
    'نگهبانی',
    'دوربین',
    'هوشمند',
    'روف گاردن',
]

// برچسب گام‌ها بسته به حالت فرم متفاوت است
export const STEPS_BY_MODE: Record<RecordMode, string[]> = {
    file: ['پایه', 'اطلاعات مالی', 'فنی', 'مالک', 'تصاویر', 'توضیحات'],
    // در «ثبت درخواست» نه مالک داریم و نه آپلود دستی تصویر
    request: ['پایه', 'اطلاعات مالی', 'فنی', 'توضیحات'],
}

export const MODE_TITLE: Record<RecordMode, string> = {
    file: 'ثبت فایل',
    request: 'ثبت درخواست',
}

// ارتفاع ثابت محتوای هر مرحله
export const STEP_CONTENT_HEIGHT = 430
